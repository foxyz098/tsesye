
var typed = new typed("span",{
    strings:["Pedro Henrique.","Web Developer.","Web Designer"],
    typeSpeed: 80,
    backSpeed: 70,
    loop: true
});